package com.example.servicecontrolcenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceControlCenterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceControlCenterApplication.class, args);
	}

}
